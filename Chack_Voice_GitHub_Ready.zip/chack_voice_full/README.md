# CHACK VOICE — Full Build

This package is the full online-app foundation, not a store build.

## Product rules
- Facebook-style social feed.
- Voice-note comments only. No text comment box.
- Users can create accounts.
- Users can create posts.
- Users can upload photos/videos.
- Users can like posts.
- Users can follow people.
- Voice comments are stored in Supabase Storage.
- Profiles and notifications have database tables.
- Your supplied image is used for the Chack Voice identity.

## Connect Supabase
1. Create/open your Supabase project.
2. Open SQL Editor.
3. Paste and run `supabase/schema.sql`.
4. Create a local `.env` file from `.env.example`.
5. Put your Supabase project URL and publishable key in `.env`.
6. Run `npm install`.
7. Run `npx expo start`.

Use only the publishable/anon key in the mobile app. Never put a Supabase service-role key in the app.

## Important
The project is deliberately prepared for the full build before store publishing. App Store and Google Play setup comes later.
