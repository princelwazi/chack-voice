# Chack Voice — Supabase connection

The project is configured for the Supabase project supplied by the owner.
The app uses only the Supabase publishable key, not a service-role key.

Next: install dependencies and open the project in Expo to continue the build.
