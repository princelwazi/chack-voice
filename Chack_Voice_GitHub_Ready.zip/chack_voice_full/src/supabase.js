import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export const supabase = createClient(url || '', key || '', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false }
});
