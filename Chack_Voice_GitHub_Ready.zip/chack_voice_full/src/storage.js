import { supabase } from './supabase';

export async function uploadFile(bucket, path, uri, contentType) {
  const response = await fetch(uri);
  const arrayBuffer = await response.arrayBuffer();
  const { error } = await supabase.storage.from(bucket).upload(path, arrayBuffer, {
    contentType,
    upsert: false
  });
  if (error) throw error;
  return path;
}

export function publicUrl(bucket, path) {
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

export async function signedVoiceUrl(path) {
  const { data, error } = await supabase.storage.from('voice-comments')
    .createSignedUrl(path, 60 * 60);
  if (error) throw error;
  return data.signedUrl;
}
