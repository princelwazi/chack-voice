import { supabase } from './supabase';

export async function signUp(email, password, username, displayName) {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) throw error;
  if (!data.user) throw new Error('Account was not created.');
  const { error: profileError } = await supabase.from('profiles').insert({
    id: data.user.id,
    username: username.trim().toLowerCase(),
    display_name: displayName.trim()
  });
  if (profileError) throw profileError;
  return data.user;
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.user;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentProfile() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
  if (error) throw error;
  return data;
}

export async function createPost(userId, body, mediaUrl = null, mediaType = null) {
  const { data, error } = await supabase.from('posts')
    .insert({ user_id: userId, body, media_url: mediaUrl, media_type: mediaType })
    .select().single();
  if (error) throw error;
  return data;
}

export async function toggleLike(userId, postId, liked) {
  if (liked) {
    const { error } = await supabase.from('likes').delete()
      .eq('user_id', userId).eq('post_id', postId);
    if (error) throw error;
  } else {
    const { error } = await supabase.from('likes').insert({ user_id: userId, post_id: postId });
    if (error) throw error;
  }
}

export async function followUser(userId, targetId, following) {
  if (following) {
    const { error } = await supabase.from('follows').delete()
      .eq('follower_id', userId).eq('following_id', targetId);
    if (error) throw error;
  } else {
    const { error } = await supabase.from('follows').insert({
      follower_id: userId, following_id: targetId
    });
    if (error) throw error;
  }
}

export async function createVoiceComment(userId, postId, audioPath, durationSeconds) {
  const { data, error } = await supabase.from('voice_comments').insert({
    user_id: userId,
    post_id: postId,
    audio_path: audioPath,
    duration_seconds: durationSeconds
  }).select().single();
  if (error) throw error;
  return data;
}
