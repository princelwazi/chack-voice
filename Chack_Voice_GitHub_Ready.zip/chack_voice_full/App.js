import React, { useEffect, useState } from 'react';
import { Alert, Image, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Audio } from 'expo-av';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from './src/supabase';
import { signIn, signUp, signOut, getCurrentProfile, createPost, toggleLike, createVoiceComment } from './src/api';
import { uploadFile, publicUrl } from './src/storage';

const myImage = require('./assets/chack-profile.png');

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session) {
        try { setProfile(await getCurrentProfile()); } catch {}
      }
      setBooting(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      setSession(newSession);
      if (newSession) {
        try { setProfile(await getCurrentProfile()); } catch {}
      } else setProfile(null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  if (booting) return <Splash />;
  if (!session) return <Auth />;
  return <SocialApp profile={profile} />;
}

function Splash() {
  return <View style={styles.splash}>
    <Image source={myImage} style={styles.splashImage} />
    <View style={styles.overlay} />
    <View style={styles.splashText}>
      <Text style={styles.splashLogo}>CHACK VOICE</Text>
      <Text style={styles.splashTag}>Your voice. Your people. Your community.</Text>
    </View>
  </View>;
}

function Auth() {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const submit = async () => {
    try {
      if (mode === 'login') await signIn(email, password);
      else {
        if (!username || !displayName) throw new Error('Please enter your name and username.');
        await signUp(email, password, username, displayName);
        Alert.alert('Account created', 'If email confirmation is enabled, confirm your email before signing in.');
      }
    } catch (e) { Alert.alert('Chack Voice', e.message); }
  };
  return <SafeAreaView style={styles.auth}>
    <Image source={myImage} style={styles.authImage} />
    <Text style={styles.authLogo}>Chack Voice</Text>
    <Text style={styles.authSub}>Voice-first social community</Text>
    {mode === 'signup' && <>
      <TextInput placeholder="Display name" value={displayName} onChangeText={setDisplayName} style={styles.input} />
      <TextInput placeholder="Username" value={username} onChangeText={setUsername} autoCapitalize="none" style={styles.input} />
    </>}
    <TextInput placeholder="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" style={styles.input} />
    <TextInput placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry style={styles.input} />
    <Pressable style={styles.primary} onPress={submit}><Text style={styles.primaryText}>{mode === 'login' ? 'Log in' : 'Create account'}</Text></Pressable>
    <Pressable onPress={() => setMode(mode === 'login' ? 'signup' : 'login')}><Text style={styles.switch}>{mode === 'login' ? 'Create a new account' : 'Already have an account? Log in'}</Text></Pressable>
  </SafeAreaView>;
}

function SocialApp({ profile }) {
  const [tab, setTab] = useState('home');
  const [posts, setPosts] = useState([]);
  const [composer, setComposer] = useState('');
  const [recording, setRecording] = useState(null);

  const loadFeed = async () => {
    const { data, error } = await supabase.from('posts')
      .select('id, body, media_url, media_type, created_at, user_id, profiles(display_name, username, avatar_url), likes(user_id), voice_comments(id, user_id, audio_path, duration_seconds, created_at, profiles(display_name, avatar_url))')
      .order('created_at', { ascending: false });
    if (!error) setPosts(data || []);
  };

  useEffect(() => { loadFeed(); }, []);

  const publish = async () => {
    if (!composer.trim() && !recording) return;
    try {
      await createPost(profile.id, composer.trim());
      setComposer('');
      await loadFeed();
    } catch (e) { Alert.alert('Post error', e.message); }
  };

  const addMediaPost = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images', 'videos'],
      quality: 0.85,
      allowsEditing: false
    });
    if (result.canceled) return;
    const asset = result.assets[0];
    try {
      const ext = asset.uri.split('.').pop() || 'jpg';
      const type = asset.type === 'video' ? 'video/mp4' : 'image/jpeg';
      const path = `${profile.id}/${Date.now()}.${ext}`;
      await uploadFile('post-media', path, asset.uri, type);
      await createPost(profile.id, composer.trim(), publicUrl('post-media', path), asset.type === 'video' ? 'video' : 'image');
      setComposer('');
      await loadFeed();
    } catch (e) { Alert.alert('Media error', e.message); }
  };

  const voiceComment = async (postId) => {
    try {
      const permission = await Audio.requestPermissionsAsync();
      if (!permission.granted) return Alert.alert('Microphone', 'Allow microphone access for voice comments.');
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const rec = new Audio.Recording();
      await rec.prepareToRecordAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
      await rec.startAsync();
      setRecording({ rec, postId, started: Date.now() });
    } catch (e) { Alert.alert('Voice comment', e.message); }
  };

  const stopVoice = async () => {
    if (!recording) return;
    try {
      await recording.rec.stopAndUnloadAsync();
      const uri = recording.rec.getURI();
      const duration = Math.max(1, Math.round((Date.now() - recording.started) / 1000));
      const path = `${profile.id}/${Date.now()}.m4a`;
      await uploadFile('voice-comments', path, uri, 'audio/m4a');
      await createVoiceComment(profile.id, recording.postId, path, duration);
      setRecording(null);
      await loadFeed();
    } catch (e) { setRecording(null); Alert.alert('Voice comment', e.message); }
  };

  const like = async (post) => {
    const liked = (post.likes || []).some(x => x.user_id === profile.id);
    try { await toggleLike(profile.id, post.id, liked); await loadFeed(); }
    catch (e) { Alert.alert('Like', e.message); }
  };

  return <SafeAreaView style={styles.app}>
    <StatusBar barStyle="dark-content" />
    {tab === 'home' && <ScrollView contentContainerStyle={styles.feed}>
      <View style={styles.top}>
        <View><Text style={styles.brand}>Chack Voice</Text><Text style={styles.muted}>Voice-first community</Text></View>
        <Image source={myImage} style={styles.topAvatar} />
      </View>

      <View style={styles.composer}>
        <Image source={myImage} style={styles.avatar} />
        <TextInput placeholder="What's happening?" value={composer} onChangeText={setComposer} style={styles.composerInput} />
        <Pressable onPress={publish} style={styles.smallPost}><Text style={styles.smallPostText}>Post</Text></Pressable>
      </View>
      <View style={styles.composerTools}>
        <Pressable onPress={addMediaPost} style={styles.tool}><Ionicons name="images-outline" size={20} color="#3867ff" /><Text>Photo / video</Text></Pressable>
        <View style={styles.tool}><Ionicons name="mic-outline" size={20} color="#3867ff" /><Text>Voice comments</Text></View>
      </View>

      {posts.map(post => <Post key={post.id} post={post} profile={profile} onLike={() => like(post)} onVoice={() => voiceComment(post.id)} />)}
    </ScrollView>}

    {tab === 'search' && <Search />}
    {tab === 'alerts' && <Alerts />}
    {tab === 'profile' && <Profile profile={profile} />}

    <View style={styles.nav}>
      <Nav icon="home" text="Home" active={tab === 'home'} onPress={() => setTab('home')} />
      <Nav icon="search" text="Search" active={tab === 'search'} onPress={() => setTab('search')} />
      <Pressable style={styles.plus} onPress={() => setTab('home')}><Ionicons name="add" size={29} color="#fff" /></Pressable>
      <Nav icon="notifications-outline" text="Alerts" active={tab === 'alerts'} onPress={() => setTab('alerts')} />
      <Nav icon="person-outline" text="Profile" active={tab === 'profile'} onPress={() => setTab('profile')} />
    </View>

    {recording && <Pressable style={styles.recordBar} onPress={stopVoice}>
      <Ionicons name="mic" size={21} color="#fff" />
      <Text style={{ color:'#fff', flex:1, fontWeight:'800' }}>Recording voice comment…</Text>
      <Text style={{ color:'#ff7d7d', fontWeight:'900' }}>STOP</Text>
    </Pressable>}
  </SafeAreaView>;
}

function Post({ post, profile, onLike, onVoice }) {
  const liked = (post.likes || []).some(x => x.user_id === profile.id);
  return <View style={styles.postCard}>
    <View style={styles.postHeader}>
      <Image source={myImage} style={styles.avatar} />
      <View style={{flex:1}}><Text style={styles.name}>{post.profiles?.display_name || 'Chack Voice user'}</Text><Text style={styles.muted}>@{post.profiles?.username || 'user'} • Public</Text></View>
      <Ionicons name="ellipsis-horizontal" size={21} color="#666" />
    </View>
    {!!post.body && <Text style={styles.body}>{post.body}</Text>}
    {!!post.media_url && <Image source={{ uri: post.media_url }} style={styles.media} />}
    <View style={styles.stats}><Text style={styles.muted}>❤️ {post.likes?.length || 0}</Text><Text style={styles.muted}>{post.voice_comments?.length || 0} voice comments</Text></View>
    <View style={styles.actions}>
      <Pressable onPress={onLike} style={styles.action}><Ionicons name={liked ? 'heart' : 'heart-outline'} size={21} color={liked ? '#e53935' : '#555'} /><Text>Like</Text></Pressable>
      <Pressable onPress={onVoice} style={styles.action}><Ionicons name="mic-outline" size={21} color="#555" /><Text>Voice comment</Text></Pressable>
      <Pressable style={styles.action}><Ionicons name="share-social-outline" size={21} color="#555" /><Text>Share</Text></Pressable>
    </View>
    {(post.voice_comments || []).map(c => <View key={c.id} style={styles.voiceComment}>
      <Image source={myImage} style={styles.smallAvatar} />
      <View style={styles.voiceBubble}><Text style={styles.voiceName}>{c.profiles?.display_name || 'User'}</Text><View style={styles.voiceInner}><Ionicons name="play" size={16} color="#fff" /><Text style={styles.voiceLabel}>Voice note • {c.duration_seconds || 0}s</Text></View></View>
    </View>)}
  </View>;
}

function Search() { return <View style={styles.page}><Text style={styles.pageTitle}>Search</Text><View style={styles.search}><Ionicons name="search" size={21} color="#777" /><TextInput placeholder="Search people and posts…" style={{flex:1}} /></View></View>; }
function Alerts() { return <View style={styles.page}><Text style={styles.pageTitle}>Notifications</Text><Text style={styles.muted}>Your activity and voice-comment notifications will appear here.</Text></View>; }
function Profile({ profile }) {
  return <ScrollView style={styles.page}><View style={styles.cover}/><Image source={myImage} style={styles.profileAvatar}/><Text style={styles.profileName}>{profile?.display_name || 'Chack'}</Text><Text style={styles.muted}>@{profile?.username || 'chack'}</Text><View style={styles.profileStats}><Text>Posts</Text><Text>Followers</Text><Text>Following</Text></View><Text style={styles.section}>About</Text><Text style={styles.about}>{profile?.bio || 'Welcome to Chack Voice.'}</Text><Pressable style={styles.logout} onPress={signOut}><Text style={styles.logoutText}>Log out</Text></Pressable></ScrollView>;
}
function Nav({icon,text,active,onPress}) { return <Pressable onPress={onPress} style={styles.navItem}><Ionicons name={icon} size={22} color={active ? '#3867ff' : '#555'} /><Text style={{fontSize:10,color:active?'#3867ff':'#555'}}>{text}</Text></Pressable>; }

const styles = StyleSheet.create({
  splash:{flex:1,backgroundColor:'#0B1020',alignItems:'center',justifyContent:'center'},
  splashImage:{position:'absolute',width:'100%',height:'100%',resizeMode:'cover'},
  overlay:{position:'absolute',width:'100%',height:'100%',backgroundColor:'rgba(4,8,20,.5)'},
  splashText:{alignItems:'center',marginTop:310},
  splashLogo:{fontSize:39,fontWeight:'900',color:'#fff',letterSpacing:2},
  splashTag:{color:'#fff',marginTop:8},
  auth:{flex:1,backgroundColor:'#f4f6fa',padding:22,justifyContent:'center',alignItems:'center'},
  authImage:{width:110,height:110,borderRadius:55,marginBottom:14},
  authLogo:{fontSize:31,fontWeight:'900',color:'#111827'},authSub:{color:'#707784',marginBottom:22},
  input:{width:'100%',backgroundColor:'#fff,borderRadius:13',padding:14,marginBottom:10},
  primary:{width:'100%',backgroundColor:'#3867ff',padding:14,borderRadius:13,alignItems:'center',marginTop:5},
  primaryText:{color:'#fff',fontWeight:'900',fontSize:16},switch:{color:'#3867ff',fontWeight:'800',marginTop:16},
  app:{flex:1,backgroundColor:'#f4f6fa'},feed:{padding:15,paddingBottom:105},
  top:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:14},
  brand:{fontSize:28,fontWeight:'900',color:'#111827'},muted:{color:'#747b88',fontSize:12},topAvatar:{width:43,height:43,borderRadius:22},
  composer:{backgroundColor:'#fff',borderRadius:16,padding:10,flexDirection:'row',alignItems:'center',gap:8},
  avatar:{width:42,height:42,borderRadius:21},composerInput:{flex:1,paddingHorizontal:7},smallPost:{backgroundColor:'#3867ff',borderRadius:10,paddingHorizontal:12,paddingVertical:9},smallPostText:{color:'#fff',fontWeight:'900'},
  composerTools:{backgroundColor:'#fff',borderBottomLeftRadius:16,borderBottomRightRadius:16,padding:10,flexDirection:'row',gap:20,marginBottom:13},
  tool:{flexDirection:'row',alignItems:'center',gap:5},postCard:{backgroundColor:'#fff',borderRadius:16,marginBottom:14,paddingTop:13,overflow:'hidden'},
  postHeader:{flexDirection:'row',alignItems:'center',paddingHorizontal:13,gap:9},name:{fontWeight:'900',fontSize:14,color:'#151922'},body:{fontSize:15,lineHeight:22,padding:14,color:'#20242b'},media:{width:'100%',height:280,resizeMode:'cover'},
  stats:{flexDirection:'row',justifyContent:'space-between',padding:10},actions:{borderTopWidth:1,borderBottomWidth:1,borderColor:'#edf0f4',flexDirection:'row',paddingVertical:9},
  action:{flex:1,alignItems:'center',flexDirection:'row',justifyContent:'center',gap:5},voiceComment:{flexDirection:'row',gap:8,padding:10},smallAvatar:{width:31,height:31,borderRadius:16},
  voiceBubble:{backgroundColor:'#f0f2f5',borderRadius:14,padding:8,flex:1},voiceName:{fontWeight:'900',fontSize:12},voiceInner:{backgroundColor:'#3867ff',borderRadius:18,paddingHorizontal:10,paddingVertical:8,flexDirection:'row',alignItems:'center',gap:8,marginTop:4},
  voiceLabel:{color:'#fff',fontWeight:'700',fontSize:12},nav:{position:'absolute',bottom:0,left:0,right:0,height:72,backgroundColor:'#fff',borderTopWidth:1,borderColor:'#e7eaf0',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},
  navItem:{alignItems:'center',minWidth:55},plus:{width:53,height:53,borderRadius:27,backgroundColor:'#3867ff',alignItems:'center',justifyContent:'center',marginTop:-25,borderWidth:4,borderColor:'#f4f6fa'},
  recordBar:{position:'absolute',bottom:78,left:12,right:12,backgroundColor:'#151a2b',borderRadius:15,padding:13,flexDirection:'row',alignItems:'center',gap:9},
  page:{flex:1,padding:15},pageTitle:{fontSize:29,fontWeight:'900',marginVertical:18},search:{backgroundColor:'#fff',borderRadius:14,padding:12,flexDirection:'row',gap:8,alignItems:'center'},cover:{height:160,backgroundColor:'#151a2b',marginHorizontal:-15},profileAvatar:{width:105,height:105,borderRadius:53,borderWidth:5,borderColor:'#f4f6fa',alignSelf:'center',marginTop:-52},profileName:{textAlign:'center',fontSize:25,fontWeight:'900',marginTop:6},profileStats:{flexDirection:'row',justifyContent:'space-around',marginVertical:20},section:{fontSize:18,fontWeight:'900',marginBottom:8},about:{backgroundColor:'#fff',padding:15,borderRadius:14,lineHeight:21},logout:{marginTop:20,backgroundColor:'#111827',padding:13,borderRadius:12,alignItems:'center'},logoutText:{color:'#fff',fontWeight:'900'}
});
