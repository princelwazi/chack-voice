-- CHACK VOICE DATABASE
-- Run this in Supabase SQL Editor.
-- This schema uses public/publishable client access with Row Level Security.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null,
  avatar_url text,
  bio text default '',
  created_at timestamptz default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text default '',
  media_url text,
  media_type text check (media_type in ('image','video') or media_type is null),
  created_at timestamptz default now()
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, post_id)
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.voice_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  audio_path text not null,
  duration_seconds integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete cascade,
  type text not null,
  post_id uuid references public.posts(id) on delete cascade,
  created_at timestamptz default now(),
  read boolean default false
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.voice_comments enable row level security;
alter table public.notifications enable row level security;

create policy "profiles readable" on public.profiles for select using (true);
create policy "users create own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "users update own profile" on public.profiles for update using (auth.uid() = id);

create policy "posts readable" on public.posts for select using (true);
create policy "users create own posts" on public.posts for insert with check (auth.uid() = user_id);
create policy "users update own posts" on public.posts for update using (auth.uid() = user_id);
create policy "users delete own posts" on public.posts for delete using (auth.uid() = user_id);

create policy "likes readable" on public.likes for select using (true);
create policy "users like as themselves" on public.likes for insert with check (auth.uid() = user_id);
create policy "users remove own likes" on public.likes for delete using (auth.uid() = user_id);

create policy "follows readable" on public.follows for select using (true);
create policy "users follow as themselves" on public.follows for insert with check (auth.uid() = follower_id);
create policy "users unfollow as themselves" on public.follows for delete using (auth.uid() = follower_id);

create policy "voice comments readable" on public.voice_comments for select using (true);
create policy "users create own voice comments" on public.voice_comments for insert with check (auth.uid() = user_id);
create policy "users delete own voice comments" on public.voice_comments for delete using (auth.uid() = user_id);

create policy "users read own notifications" on public.notifications for select using (auth.uid() = recipient_id);
create policy "users update own notifications" on public.notifications for update using (auth.uid() = recipient_id);

-- Storage buckets
insert into storage.buckets (id, name, public) values ('avatars','avatars',true)
on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('post-media','post-media',true)
on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('voice-comments','voice-comments',false)
on conflict (id) do nothing;

create policy "avatar upload own folder" on storage.objects for insert
with check (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "avatar public read" on storage.objects for select
using (bucket_id = 'avatars');

create policy "post media upload own folder" on storage.objects for insert
with check (bucket_id = 'post-media' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "post media public read" on storage.objects for select
using (bucket_id = 'post-media');

create policy "voice upload own folder" on storage.objects for insert
with check (bucket_id = 'voice-comments' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "voice owner read" on storage.objects for select
using (bucket_id = 'voice-comments' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "voice owner delete" on storage.objects for delete
using (bucket_id = 'voice-comments' and auth.uid()::text = (storage.foldername(name))[1]);
