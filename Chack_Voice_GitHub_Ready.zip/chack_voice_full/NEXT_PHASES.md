# CHACK VOICE — Build phases

## Already prepared
- Branded splash screen
- Account registration/login
- Profiles
- Home feed
- Posts
- Photo/video uploads
- Likes
- Follows database
- Voice-only comments
- Voice recording and upload
- Notifications database
- Search screen foundation
- Store-ready package structure

## Next development work
- Feed pagination
- Real follow/unfollow UI
- Real search results
- Play voice comments from storage using signed URLs
- Video playback
- Notification triggers
- Profile editing
- Report/block/moderation
- Content privacy controls
- Password reset
- Email verification flow
- Better media compression
- Offline handling
- Production security review

## Later
- Google Play build
- Apple App Store build
- Privacy policy
- Terms
- App screenshots and store listing
