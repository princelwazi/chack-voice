import React, { useEffect, useState } from 'react';
import {
  Alert,
  Image,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View
} from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';

const profileImage = require('./assets/chack-profile.png');

const demoPosts = [
  {
    id: '1',
    name: 'Chack',
    time: 'Just now',
    text: 'Welcome to Chack Voice 🎤 — a place where people can connect with posts, pictures and voice comments.',
    image: profileImage,
    likes: 24,
    liked: false,
    comments: [
      { id: 'c1', name: 'Thando', text: 'This is fire 🔥', voice: false },
      { id: 'c2', name: 'Lwazi', text: '', voice: true, duration: '0:07' }
    ]
  },
  {
    id: '2',
    name: 'Chack',
    time: '2h',
    text: 'Your voice can be part of the conversation. Tap the microphone on a post to record a voice comment.',
    likes: 81,
    liked: false,
    comments: []
  }
];

export default function App() {
  const [screen, setScreen] = useState('splash');
  const [posts, setPosts] = useState(demoPosts);
  const [newPost, setNewPost] = useState('');
  const [commentInputs, setCommentInputs] = useState({});
  const [recording, setRecording] = useState(null);
  const [recordingPostId, setRecordingPostId] = useState(null);
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setScreen('home'), 2200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    let timer;
    if (recording) {
      timer = setInterval(() => setSeconds(s => s + 1), 1000);
    }
    return () => timer && clearInterval(timer);
  }, [recording]);

  const toggleLike = (id) => {
    setPosts(current =>
      current.map(post =>
        post.id === id
          ? { ...post, liked: !post.liked, likes: post.likes + (post.liked ? -1 : 1) }
          : post
      )
    );
  };

  const addComment = (postId) => {
    const text = (commentInputs[postId] || '').trim();
    if (!text) return;
    setPosts(current =>
      current.map(post =>
        post.id === postId
          ? {
              ...post,
              comments: [...post.comments, {
                id: Date.now().toString(),
                name: 'You',
                text,
                voice: false
              }]
            }
          : post
      )
    );
    setCommentInputs(v => ({ ...v, [postId]: '' }));
  };

  const startVoiceComment = async (postId) => {
    try {
      const permission = await Audio.requestPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Microphone permission', 'Please allow microphone access to record a voice comment.');
        return;
      }
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true
      });
      const rec = new Audio.Recording();
      await rec.prepareToRecordAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
      await rec.startAsync();
      setRecording(rec);
      setRecordingPostId(postId);
      setSeconds(0);
    } catch (e) {
      Alert.alert('Recording error', 'The microphone could not be started on this device.');
    }
  };

  const stopVoiceComment = async () => {
    if (!recording) return;
    try {
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      const postId = recordingPostId;
      const duration = `0:${String(Math.max(1, seconds)).padStart(2, '0')}`;
      setPosts(current =>
        current.map(post =>
          post.id === postId
            ? {
                ...post,
                comments: [...post.comments, {
                  id: Date.now().toString(),
                  name: 'You',
                  text: '',
                  voice: true,
                  duration,
                  uri
                }]
              }
            : post
        )
      );
    } catch (e) {
      Alert.alert('Recording error', 'The voice comment could not be saved.');
    } finally {
      setRecording(null);
      setRecordingPostId(null);
      setSeconds(0);
    }
  };

  const createPost = () => {
    const text = newPost.trim();
    if (!text) return;
    const post = {
      id: Date.now().toString(),
      name: 'Chack',
      time: 'Now',
      text,
      image: profileImage,
      likes: 0,
      liked: false,
      comments: []
    };
    setPosts(current => [post, ...current]);
    setNewPost('');
    setScreen('home');
  };

  if (screen === 'splash') {
    return (
      <View style={styles.splash}>
        <StatusBar barStyle="light-content" />
        <Image source={profileImage} style={styles.splashImage} />
        <View style={styles.splashShade} />
        <View style={styles.splashContent}>
          <Text style={styles.logo}>CHACK VOICE</Text>
          <Text style={styles.tagline}>Your voice. Your people. Your community.</Text>
          <View style={styles.loadingDot} />
        </View>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      {screen === 'home' && (
        <Home
          posts={posts}
          onLike={toggleLike}
          onComment={addComment}
          commentInputs={commentInputs}
          setCommentInputs={setCommentInputs}
          onVoice={startVoiceComment}
          recordingPostId={recordingPostId}
          recording={recording}
        />
      )}
      {screen === 'search' && <Search />}
      {screen === 'notifications' && <Notifications />}
      {screen === 'profile' && <Profile />}

      {screen === 'create' && (
        <CreatePost
          value={newPost}
          setValue={setNewPost}
          onPost={createPost}
          onBack={() => setScreen('home')}
        />
      )}

      {screen !== 'create' && (
        <View style={styles.nav}>
          <NavItem icon="home" label="Home" active={screen === 'home'} onPress={() => setScreen('home')} />
          <NavItem icon="search" label="Search" active={screen === 'search'} onPress={() => setScreen('search')} />
          <Pressable style={styles.createButton} onPress={() => setScreen('create')}>
            <Ionicons name="add" size={30} color="#fff" />
          </Pressable>
          <NavItem icon="notifications-outline" label="Alerts" active={screen === 'notifications'} onPress={() => setScreen('notifications')} />
          <NavItem icon="person-outline" label="Profile" active={screen === 'profile'} onPress={() => setScreen('profile')} />
        </View>
      )}

      {recording && (
        <Pressable style={styles.recordingBar} onPress={stopVoiceComment}>
          <Ionicons name="mic" size={22} color="#fff" />
          <Text style={styles.recordingText}>Recording voice comment • 0:{String(seconds).padStart(2, '0')}</Text>
          <Text style={styles.stopText}>STOP</Text>
        </Pressable>
      )}
    </SafeAreaView>
  );
}

function Home({ posts, onLike, onComment, commentInputs, setCommentInputs, onVoice, recordingPostId }) {
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 110 }}>
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>Chack Voice</Text>
          <Text style={styles.smallMuted}>Connect through your voice</Text>
        </View>
        <Image source={profileImage} style={styles.headerAvatar} />
      </View>

      <View style={styles.storyCard}>
        <Image source={profileImage} style={styles.storyImage} />
        <View>
          <Text style={styles.storyTitle}>Create your story</Text>
          <Text style={styles.smallMuted}>Share what is happening.</Text>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#777" />
      </View>

      {posts.map(post => (
        <PostCard
          key={post.id}
          post={post}
          onLike={() => onLike(post.id)}
          commentValue={commentInputs[post.id] || ''}
          setCommentValue={(v) => setCommentInputs(x => ({ ...x, [post.id]: v }))}
          onComment={() => onComment(post.id)}
          onVoice={() => onVoice(post.id)}
          recording={recordingPostId === post.id}
        />
      ))}
    </ScrollView>
  );
}

function PostCard({ post, onLike, commentValue, setCommentValue, onComment, onVoice, recording }) {
  return (
    <View style={styles.post}>
      <View style={styles.postHeader}>
        <Image source={profileImage} style={styles.avatar} />
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{post.name}</Text>
          <Text style={styles.smallMuted}>{post.time} • 🌍</Text>
        </View>
        <Ionicons name="ellipsis-horizontal" size={22} color="#555" />
      </View>

      <Text style={styles.postText}>{post.text}</Text>
      {post.image && <Image source={post.image} style={styles.postImage} />}

      <View style={styles.stats}>
        <Text style={styles.smallMuted}>❤️ {post.likes}</Text>
        <Text style={styles.smallMuted}>{post.comments.length} comments</Text>
      </View>

      <View style={styles.actions}>
        <Pressable style={styles.action} onPress={onLike}>
          <Ionicons name={post.liked ? 'heart' : 'heart-outline'} size={22} color={post.liked ? '#e53935' : '#555'} />
          <Text style={styles.actionText}>Like</Text>
        </Pressable>
        <Pressable style={styles.action}>
          <Ionicons name="chatbubble-outline" size={21} color="#555" />
          <Text style={styles.actionText}>Comment</Text>
        </Pressable>
        <Pressable style={styles.action}>
          <Ionicons name="share-social-outline" size={21} color="#555" />
          <Text style={styles.actionText}>Share</Text>
        </Pressable>
      </View>

      {post.comments.map(c => (
        <View key={c.id} style={styles.comment}>
          <Image source={profileImage} style={styles.commentAvatar} />
          <View style={styles.commentBubble}>
            <Text style={styles.commentName}>{c.name}</Text>
            {c.voice ? (
              <View style={styles.voiceBubble}>
                <Ionicons name="play" size={17} color="#fff" />
                <View style={styles.wave}><View /><View /><View /><View /><View /><View /><View /></View>
                <Text style={styles.voiceDuration}>{c.duration}</Text>
              </View>
            ) : <Text style={styles.commentText}>{c.text}</Text>}
          </View>
        </View>
      ))}

      <View style={styles.commentRow}>
        <Image source={profileImage} style={styles.commentAvatar} />
        <TextInput
          value={commentValue}
          onChangeText={setCommentValue}
          placeholder="Write a comment..."
          placeholderTextColor="#888"
          style={styles.commentInput}
          onSubmitEditing={onComment}
        />
        <Pressable style={styles.micButton} onPress={onVoice}>
          <Ionicons name={recording ? 'stop' : 'mic'} size={21} color="#fff" />
        </Pressable>
        <Pressable onPress={onComment}>
          <Ionicons name="send" size={22} color="#3867ff" />
        </Pressable>
      </View>
    </View>
  );
}

function CreatePost({ value, setValue, onPost, onBack }) {
  return (
    <View style={styles.container}>
      <View style={styles.createHeader}>
        <Pressable onPress={onBack}><Ionicons name="close" size={28} color="#111" /></Pressable>
        <Text style={styles.createTitle}>Create post</Text>
        <Pressable onPress={onPost}><Text style={styles.postNow}>POST</Text></Pressable>
      </View>
      <View style={styles.createProfile}>
        <Image source={profileImage} style={styles.avatar} />
        <View>
          <Text style={styles.name}>Chack</Text>
          <Text style={styles.smallMuted}>Public 🌍</Text>
        </View>
      </View>
      <TextInput
        multiline
        autoFocus
        value={value}
        onChangeText={setValue}
        placeholder="What's on your mind?"
        placeholderTextColor="#888"
        style={styles.postComposer}
      />
      <View style={styles.createOptions}>
        <Option icon="image-outline" text="Photo / Video" />
        <Option icon="mic-outline" text="Voice" />
        <Option icon="happy-outline" text="Feeling" />
      </View>
    </View>
  );
}

function Option({ icon, text }) {
  return (
    <View style={styles.option}>
      <Ionicons name={icon} size={25} color="#3867ff" />
      <Text style={styles.optionText}>{text}</Text>
    </View>
  );
}

function Search() {
  return (
    <View style={styles.container}>
      <Text style={styles.pageTitle}>Search</Text>
      <View style={styles.searchBox}>
        <Ionicons name="search" size={21} color="#777" />
        <TextInput placeholder="Search people, posts..." style={{ flex: 1 }} />
      </View>
      <Text style={styles.sectionTitle}>People you may know</Text>
      {['Thando', 'Lwazi', 'Siyabonga'].map((name, i) => (
        <View key={name} style={styles.personRow}>
          <Image source={profileImage} style={styles.avatar} />
          <Text style={styles.name}>{name}</Text>
          <Pressable style={styles.follow}><Text style={styles.followText}>Follow</Text></Pressable>
        </View>
      ))}
    </View>
  );
}

function Notifications() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.pageTitle}>Notifications</Text>
      {['Thando liked your post', 'Lwazi commented with a voice note', 'Siyabonga started following you'].map((t, i) => (
        <View key={i} style={styles.notification}>
          <View style={styles.notificationIcon}><Ionicons name={i === 1 ? 'mic' : 'heart'} size={20} color="#fff" /></View>
          <View style={{ flex: 1 }}><Text style={styles.notificationText}>{t}</Text><Text style={styles.smallMuted}>Today</Text></View>
        </View>
      ))}
    </ScrollView>
  );
}

function Profile() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 100 }}>
      <View style={styles.profileCover} />
      <Image source={profileImage} style={styles.profileImage} />
      <Text style={styles.profileName}>Chack</Text>
      <Text style={styles.smallMuted}>Chack Voice creator</Text>
      <View style={styles.profileStats}>
        <Stat number="128" label="Posts" />
        <Stat number="4.8K" label="Followers" />
        <Stat number="312" label="Following" />
      </View>
      <Pressable style={styles.editProfile}><Text style={styles.editText}>Edit profile</Text></Pressable>
      <Text style={styles.sectionTitle}>About</Text>
      <Text style={styles.about}>Welcome to my Chack Voice profile. Follow me and join the conversation with text or your voice.</Text>
    </ScrollView>
  );
}

function Stat({ number, label }) {
  return <View style={{ alignItems: 'center' }}><Text style={styles.statNumber}>{number}</Text><Text style={styles.smallMuted}>{label}</Text></View>;
}

function NavItem({ icon, label, active, onPress }) {
  return (
    <Pressable style={styles.navItem} onPress={onPress}>
      <Ionicons name={icon} size={23} color={active ? '#3867ff' : '#555'} />
      <Text style={[styles.navLabel, active && { color: '#3867ff' }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f4f6fa' },
  splash: { flex: 1, backgroundColor: '#0B1020', alignItems: 'center', justifyContent: 'center' },
  splashImage: { position: 'absolute', width: '100%', height: '100%' },
  splashShade: { position: 'absolute', width: '100%', height: '100%', backgroundColor: 'rgba(5,10,25,0.45)' },
  splashContent: { alignItems: 'center', marginTop: 320 },
  logo: { color: '#fff', fontSize: 38, fontWeight: '900', letterSpacing: 2 },
  tagline: { color: '#fff', opacity: 0.9, marginTop: 8, fontSize: 14 },
  loadingDot: { marginTop: 22, width: 8, height: 8, borderRadius: 4, backgroundColor: '#fff' },
  container: { flex: 1, paddingHorizontal: 15 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 16 },
  brand: { fontSize: 27, fontWeight: '900', color: '#111827' },
  smallMuted: { color: '#707784', fontSize: 12 },
  headerAvatar: { width: 42, height: 42, borderRadius: 21 },
  storyCard: { backgroundColor: '#fff', borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  storyImage: { width: 50, height: 50, borderRadius: 25 },
  storyTitle: { fontWeight: '800', fontSize: 15, flex: 1 },
  post: { backgroundColor: '#fff', borderRadius: 16, marginBottom: 14, paddingTop: 14, overflow: 'hidden' },
  postHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, gap: 10 },
  avatar: { width: 42, height: 42, borderRadius: 21 },
  name: { fontWeight: '800', color: '#111827', fontSize: 14 },
  postText: { fontSize: 15, lineHeight: 22, color: '#20242b', padding: 14 },
  postImage: { width: '100%', height: 280, resizeMode: 'cover' },
  stats: { flexDirection: 'row', justifyContent: 'space-between', padding: 11 },
  actions: { flexDirection: 'row', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#edf0f4', paddingVertical: 8 },
  action: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  actionText: { color: '#555', fontWeight: '700', fontSize: 13 },
  comment: { flexDirection: 'row', paddingHorizontal: 12, paddingTop: 10, gap: 8 },
  commentAvatar: { width: 31, height: 31, borderRadius: 16 },
  commentBubble: { backgroundColor: '#f0f2f5', borderRadius: 14, paddingHorizontal: 11, paddingVertical: 7, maxWidth: '86%' },
  commentName: { fontWeight: '800', fontSize: 12 },
  commentText: { fontSize: 13, marginTop: 2 },
  voiceBubble: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#3867ff', borderRadius: 18, padding: 7, marginTop: 4, gap: 7 },
  wave: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  wave: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  voiceDuration: { color: '#fff', fontSize: 11 },
  commentRow: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 7 },
  commentInput: { flex: 1, backgroundColor: '#f0f2f5', borderRadius: 20, paddingHorizontal: 13, paddingVertical: Platform.OS === 'ios' ? 9 : 7 },
  micButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#3867ff', alignItems: 'center', justifyContent: 'center' },
  nav: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 72, backgroundColor: '#fff', borderTopWidth: 1, borderColor: '#e8ebef', flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', paddingBottom: 5 },
  navItem: { alignItems: 'center', minWidth: 55 },
  navLabel: { fontSize: 10, marginTop: 2, color: '#555', fontWeight: '700' },
  createButton: { width: 53, height: 53, borderRadius: 27, backgroundColor: '#3867ff', alignItems: 'center', justifyContent: 'center', marginTop: -25, borderWidth: 4, borderColor: '#f4f6fa' },
  recordingBar: { position: 'absolute', bottom: 76, left: 12, right: 12, backgroundColor: '#151a2b', borderRadius: 15, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 9 },
  recordingText: { color: '#fff', flex: 1, fontWeight: '700' },
  stopText: { color: '#ff7272', fontWeight: '900' },
  pageTitle: { fontSize: 29, fontWeight: '900', marginVertical: 18 },
  searchBox: { backgroundColor: '#fff', borderRadius: 14, paddingHorizontal: 13, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 8 },
  sectionTitle: { fontSize: 18, fontWeight: '900', marginTop: 24, marginBottom: 12 },
  personRow: { backgroundColor: '#fff', padding: 12, borderRadius: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  follow: { marginLeft: 'auto', backgroundColor: '#3867ff', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10 },
  followText: { color: '#fff', fontWeight: '800' },
  notification: { backgroundColor: '#fff', borderRadius: 14, padding: 12, flexDirection: 'row', gap: 12, marginBottom: 9, alignItems: 'center' },
  notificationIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#3867ff', alignItems: 'center', justifyContent: 'center' },
  notificationText: { fontWeight: '700' },
  createHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 15 },
  createTitle: { fontSize: 18, fontWeight: '900' },
  postNow: { color: '#3867ff', fontWeight: '900' },
  createProfile: { flexDirection: 'row', gap: 10, alignItems: 'center', marginTop: 10 },
  postComposer: { height: 240, fontSize: 20, textAlignVertical: 'top', marginTop: 20 },
  createOptions: { borderTopWidth: 1, borderColor: '#ddd', paddingTop: 15, gap: 14 },
  option: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  optionText: { fontWeight: '800' },
  profileCover: { height: 160, backgroundColor: '#151a2b', marginHorizontal: -15 },
  profileImage: { width: 105, height: 105, borderRadius: 53, borderWidth: 5, borderColor: '#f4f6fa', marginTop: -52, alignSelf: 'center' },
  profileName: { textAlign: 'center', fontSize: 25, fontWeight: '900', marginTop: 5 },
  profileStats: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 22 },
  statNumber: { fontSize: 19, fontWeight: '900' },
  editProfile: { borderWidth: 1, borderColor: '#cfd4dd', borderRadius: 12, padding: 11, alignItems: 'center' },
  editText: { fontWeight: '800' },
  about: { backgroundColor: '#fff', borderRadius: 14, padding: 15, lineHeight: 21, color: '#444' }
});
