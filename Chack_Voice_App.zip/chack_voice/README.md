# Chack Voice

A professional social-network starter app for Android and iPhone.

## What is already included

- Chack Voice branding
- Your supplied picture on the opening screen and profile
- Facebook-style home feed
- Create-post screen
- Like button
- Text comments
- Voice-comment recording UI using the phone microphone
- Profile screen
- Search screen
- Notifications screen
- Bottom navigation
- Local demo data so the app can run without a paid backend

## Start it for free

1. Install Node.js on a computer.
2. Open this project folder in a terminal.
3. Run:
   `npm install`
4. Run:
   `npx expo start`
5. Install Expo Go on your Android phone and scan the QR code.

## Important

This first version stores demo posts in memory on the device. It is a working front-end prototype, not yet a multi-user production social network.

For the real online version, connect the app to Supabase:
- Authentication for accounts
- Post database
- Likes/comments
- Storage for photos/videos/voice recordings
- Row Level Security

Do not put a Supabase service-role key inside this app. Only use the public/publishable key.

## App Store / Play Store later

When the app is ready, an Expo/EAS build can create production Android and iOS builds. You will still need your own Google Play Console and Apple Developer accounts to publish.
