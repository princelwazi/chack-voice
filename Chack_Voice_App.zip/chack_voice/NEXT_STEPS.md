# Chack Voice — next build

## Phase 1: Test
- Run the Expo app.
- Confirm splash screen.
- Confirm feed.
- Test text comments.
- Test microphone permission and voice recording.

## Phase 2: Make it truly online
Use Supabase for:
1. sign up / login
2. profiles
3. posts
4. likes
5. text comments
6. voice comments
7. image/video storage
8. follows
9. notifications

## Phase 3: Release
- Set app icon and splash artwork.
- Add privacy policy and terms.
- Test on several Android phones.
- Build Android APK/AAB.
- Build iOS archive with EAS.
- Publish through Google Play Console and Apple App Store Connect.

The app can remain free to build/test; store publishing accounts may have their own fees.
