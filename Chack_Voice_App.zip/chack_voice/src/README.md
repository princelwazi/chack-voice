Future backend structure:

src/
  services/
    supabase.js
  components/
  screens/
  utils/

The current prototype intentionally keeps everything in App.js so it is easy to paste/run for a first test. Once the design is approved, the code can be split into production files and connected to Supabase.
